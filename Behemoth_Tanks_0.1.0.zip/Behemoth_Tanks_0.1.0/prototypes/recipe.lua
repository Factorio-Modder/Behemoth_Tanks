data:extend({

{
    type = "recipe",
    name = "behemoth-tank",
    energy_required = 60,
    enabled = true,
    ingredients =
    {
      {"engine-unit", 50},
      {"electric-engine-unit", 20},
      {"steel-plate", 100},
      {"iron-gear-wheel", 50},
      {"processing-unit", 10},
      {"battery", 50}
                
    },
    result = "behemoth-tank"
  }
        
})