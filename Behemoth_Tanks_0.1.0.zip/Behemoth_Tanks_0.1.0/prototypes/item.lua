data:extend({
        
{
    type = "item",
    name = "behemoth-tank",
    icon = "__base__/graphics/icons/tank.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport",
    order = "c[personal-transport]-c[tank]",
    place_result = "behemoth-tank",
    stack_size = 1
  }
        
})