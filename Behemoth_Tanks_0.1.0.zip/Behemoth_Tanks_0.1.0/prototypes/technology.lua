data:extend({

{
    type = "technology",
    name = "behemoth-tanks",
    icon = "__base__/graphics/technology/tanks.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "behemoth-tank"
      },
    },
    prerequisites = {"tanks"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 60
    },
    order = "e-c-d"
  },

})