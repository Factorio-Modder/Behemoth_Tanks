require("prototypes.item")
require("prototypes.entity")
require("prototypes.recipe")
require("prototypes.technology")